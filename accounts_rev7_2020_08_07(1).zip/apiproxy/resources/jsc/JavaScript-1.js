//js to parse the pathsuffix and take out the resource name and append to targeturl
context.setVariable("target.copy.pathsuffix", false);
var targetserver = context.getVariable("target.url");
var proxySuffix = context.getVariable("proxy.pathsuffix");
var proxySuffixFragments = proxySuffix.split("/");
// remove the first part
proxySuffixFragments.splice(0, 2);
var targetpathsuffix = proxySuffixFragments.join("/");
var targeturl = targetserver + targetpathsuffix
context.setVariable("targetpathsuffix", targetpathsuffix);